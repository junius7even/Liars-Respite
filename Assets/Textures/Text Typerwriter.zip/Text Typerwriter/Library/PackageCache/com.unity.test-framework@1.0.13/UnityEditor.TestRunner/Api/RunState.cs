namespace UnityEditor.TestTools.TestRunner.Api
{
    internal enum RunState
    {
        NotRunnable,
        Runnable,
        Explicit,
        Skipped,
        Ignored,
    }
}
